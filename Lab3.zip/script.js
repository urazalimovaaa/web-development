let todoItems = [];

function addTodo(text) {
  const todo = {
    text,
    checked: false,
    id: Date.now(),
  };

  todoItems.push(todo);

  const list = document.querySelector('.list-group');
  list.insertAdjacentHTML('beforeend', `
	<li class="list-group-item" data-key="${todo.id}">
	<div class="row">
        <div class="col-md-1"><input class="check" id="${todo.id}" type="checkbox"/></div>
        <div class="col-md-10"><label data-id="${todo.id}" class="mylb">${todo.text}</label> </div>
        <div class="col-md-1"><button class="btn btn-linl" data-id="${todo.id}"><i class="fas fa-trash-alt" style="color: tomato;"></i></button></div>
    </div>
     </li>
  `);
}


function toggleDone(key) {
	const index = todoItems.findIndex(item => item.id === Number(key));
  todoItems[index].checked = !todoItems[index].checked;
	console.log(index, todoItems);
	

  const item = document.querySelector(`[data-id='${key}']`);
  if (todoItems[index].checked) {
    item.classList.add('done');
  } else {
    item.classList.remove('done');
  }
  }

  function deleteTodo(key) {
	
	const item = document.querySelector(`[data-key='${key}']`);
	item.remove();
  }
  
  
  const form = document.querySelector('.myrow');
  form.addEventListener('click', event => {
	event.preventDefault();
	const input = document.querySelector('.form-control');
  
	const text = input.value.trim();
	if (text !== '') {
	  addTodo(text);
	  input.value = '';
	  input.focus();
	}
  });
  
  const list = document.querySelector('.list-group');
 	list.addEventListener('click', event => {
	if (event.target.classList.contains('check')) {
	  	const itemKey = event.target.parentElement.dataset.key;
    	toggleDone(itemKey);
	  
	}

	if (event.target.classList.contains('fa-trash-alt')) {
		const itemKey = event.target.parentElement.dataset.id;
		deleteTodo(itemKey);
	  }

  });

 
